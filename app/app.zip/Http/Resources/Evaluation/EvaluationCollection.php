<?php

namespace App\Http\Resources\Evaluation;

use Illuminate\Http\Resources\Json\ResourceCollection;

class EvaluationCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
